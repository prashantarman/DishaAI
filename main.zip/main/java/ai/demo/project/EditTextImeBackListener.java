package ai.demo.project;

public interface EditTextImeBackListener
	{
	public abstract void onImeBack(EditTextBackEvent ctrl, String text);
	}