package ai.demo.project;

public class SmsConstant
	{
    public static final String SMS_URI = "content://sms/";
    public static final String SMS_SENT_URI = "content://sms/sent";

    public static final String PDUS = "pdus";

    public static final String COLUMN_ADDRESS = "address";
    public static final String COLUMN_BODY = "body";
	}